# For managing path
import os.path
from pathlib import Path

# For reading input
import argparse

# For debug
import pdb

# BFS
import collections

# To check the answer
import filecmp

# Define relative path
PROJECT_PATH = Path(__file__).resolve().parent.as_posix()
DATA_PATH = os.path.join(PROJECT_PATH, "sample1")

# Define component of expression
ALPHABET = ['0','1']
OPERATOR = ['*', '.', '+']
# PARENTHESES = ['(', ')']

# pt.1: to postfix
"""
    TODO:
        * convert infix regex to postfix regex
    Args:
        * regex(str): infix string representing regex
    Returns:
        * result(str): postfix string representing same regex
"""
def infix2postfix(regex: str) -> str:
    result = "" # Result string
    stack = [] # Stack to convert postfix
    # print(regex)

    # Read each char in string
    for char in regex:
        #print(char)
        
        # append to result string if char is alphabet
        if char in ALPHABET:
            result += char
        # keep in stack if char is operator
        elif (char in OPERATOR) or (char is '('):
            stack.append(char)
        # append stacked operators to result string if parentheses are paired
        elif char is ')':
            while(True):
                # if all operators are parsed
                if len(stack) == 0:
                    break
                else:
                    oper = stack.pop()
                    # if parentheses are paired
                    if oper is '(':
                        break
                    # append to result string
                    else:
                        result += oper
        # if unvalid input is given
        else:
            return "INVALID"
    # print("Done!")
    return result

# Constructing NFA Transition table
"""
    TODO:
        * translate the regular expression to NFA
    Args:
        * postfix_regex(str): regex string
    Returns:
        * state_arr(array): n * 4 array that defines NFA. 
        * n stands for number of states.
        * each column is (isfinal, 0, 1, epsilon)
"""
def NFATransition(postfix_regex: str) -> list:
    # Define stack to calculate the operator
    stack = []
    state_arr = []
    current = 0
    for char in postfix_regex:
        #print(postfix_regex)
        #print("before the input " + char)
        #pretty_print(state_arr)
        #pdb.set_trace()
        if char is not '.':
            after = current + 1
        if char in ALPHABET:
            stack.append((current, after))
            # [state, isfinal, 0-transition, 1-transition, e-transition]
            if char is '0':
                #pdb.set_trace()
                state_arr.append([current, False, after, -1, []])
                state_arr.append([after, True, -1, -1, []])
                #pdb.set_trace()
            elif char is '1':
                state_arr.append([current, False, -1, after, []])
                state_arr.append([after, True, -1, -1, []])
        elif char in OPERATOR:
            if (char is '+') or (char is '.'):
                operand2 = stack.pop()
                operand1 = stack.pop()
                if char is '+':
                    # make two new states: current and after
                    # current goes to starts of operands
                    state_arr.append([current, False, -1, -1, [operand1[0], operand2[0]]])
                    # after receives ends of operands
                    state_arr[operand1[1]][4].append(after)
                    state_arr[operand1[1]][1] = False
                    state_arr[operand2[1]][4].append(after)
                    state_arr[operand2[1]][1] = False
                    state_arr.append([after, True, -1, -1, []])
                    #push new states into stack
                    stack.append((current, after))
                elif char is '.':
                    # merge end of operand1 and start of operand2 by epsilon
                    state_arr[operand1[1]][4].append(operand2[0])
                    state_arr[operand1[1]][1] = False
                    stack.append((operand1[0], operand2[1]))
            elif char is '*':
                operand = stack.pop()
                # end goes start by epsilon
                state_arr[operand[1]][4] += [operand[0], after]
                #state_arr[operand[1]][4].append(operand[0])
                #state_arr[operand[1]][4].append(after)
                state_arr[operand[1]][1] = False
                # current states goes start of operand and after by epsilon
                state_arr.append([current, False, -1, -1, [operand[0], after]])
                state_arr.append([after, True, -1, -1, []])
                #state_arr[current] = [current, False, -1, -1, [operand[0], after]]
                #state_arr[after] = [after, True, -1, -1, []]
                stack.append((current, after))
        if char is not '.':
            current = after + 1
        #print("After the next string " + char)
        #pretty_print(state_arr)
        #print(stack)
    return state_arr
        #pdb.set_trace()


    #for char in regex

# Only for debug
def pretty_print(matrix: list) -> None:
    print('\n'.join(['\t'.join([str(cell) for cell in row]) for row in matrix]))

# pt.2: run NFA for given input string
"""
    TODO:
        * validate whether the given string is NFA
    Args:
        * NFA():
        * input_string(str): input string that needs to be validated whether it is in given NFA or not
    Returns:
        * True: if given string is in given NFA
        * False: if given string is not in given NFA
"""
def run_NFA(NFA: list, input_string: str) -> bool:
    # allows epsilon string
    # pass
    #current_str = ""
    current_states = append_epsilon_states([0], NFA)
    #print(current_states)
    for char in input_string:
        #print(char)
        next_states = []
        for state in current_states:
            #print(state)
            #pdb.set_trace()
            if char is '0':
                #print("char is 0")
                next_state = NFA[state][2]
            elif char is '1':
                next_state = NFA[state][3]
            
            if next_state is not -1:
                next_states.append(next_state)
            #pdb.set_trace()
            #print(next_states)
            current_states = append_epsilon_states(next_states, NFA)
            #print(current_states)

        #print(current_states)
        #print(current_states)
    return determine_final_states(current_states, NFA)

"""
    TODO:
        * from current states C -> get E(C)
        * Using BFS
    Args:
        * current_states(list): list of current states
        * NFA(list): running NFA
    Returns:
        * current_States(list): append epsilon states to current states
"""
def append_epsilon_states(current_states: list, NFA: list) -> set:
    #print(current_states)
    result = current_states
    seen_each_state = set([])
    for state in current_states:
        #print(state)
        seen, queue = set([state]), collections.deque([state])
        #print(seen)
        #print(queue)
        while queue:
            next_state = queue.popleft()
            #print(next_state)
            #print(NFA[next_state][4])
            for epsilon_state in NFA[next_state][4]:
                #print(epsilon_state)
                if epsilon_state not in seen:
                    seen.add(epsilon_state)
                    queue.append(epsilon_state)
                #print("########")
        #print(seen)
        #print(seen_each_state)
        seen_each_state = seen_each_state.union(seen)
        #print(seen_each_state)
    return seen_each_state
        #pretty_print(NFA)
        # should use bfs
    """
        epsilon_states = NFA[state][4]
        if len(epsilon_states) is not 0:
            current_states += epsilon_states
    return current_states
    """

"""
    TODO: 
        * determine whether current state includes final
    Args:
        * current_states(list): list of current states
        * NFA(list): running NFA
    Returns:
        * Bool: True if it has final states; False o.w.
"""
def determine_final_states(current_states: list, NFA: list) -> bool:
    print(current_states)
    for state in current_states:
        if NFA[state][1] is True:
            return True
    return False

"""
    TODO:
        * Read input file
        * Parse regex to postfix
        * create NFA Table based on postfix
        * Read input string
        * validate input string
        * write result to new file and compare with the answer
"""

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type = str, default = "sample1_in.txt")
    parser.add_argument('--answer', type = str, default = "sample1_out.txt")

    args = parser.parse_args()
    
    filepath = os.path.join(DATA_PATH, args.input)

    # Read input file file
    with open(filepath, 'r') as f:

        # write result in one string
        result = ""

        # Read regex
        regex = f.readline()[:-1]
        #print(regex)
        # Convert to postfix
        postfix_regex = infix2postfix(regex)
        #print(postfix_regex)

        # Construct NFA based on postfix
        nfa = NFATransition(postfix_regex)
        #pretty_print(nfa)
        # Read num of inputs
        num_of_input = int(f.readline()[:-1])
        #print(num_of_input)

        # Read each input string
        for i in range(0, num_of_input):
            input_string = f.readline()[:-1]
            #print(input_string)

            # Validate the input
            if run_NFA(nfa, input_string):
                result += "Yes\n"
                print("Yes")
            else:
                result += 'No\n'
                print("No")
    
    # Check the answer
    answerpath = os.path.join(DATA_PATH, args.answer)

    with open(answerpath, 'r') as f:
        f = f.read()
        if result == f:
            print('Success')
        else:
            print('Fail')

# Run function
if __name__ == "__main__":
    main()